interface IBProperties {
  a: any
}

const b:IBProperties = {a: "a"}